import {
  HttpInterceptorFn,
  HttpRequest,
  HttpHandlerFn,
  HttpEvent,
} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';

export const httpInterceptor: HttpInterceptorFn = (
  request: HttpRequest<any>,
  next: HttpHandlerFn
): Observable<HttpEvent<any>> => {
  console.log('intercepted request ... ', request.method);
  if (request.method === 'DELETE') {
    const confirmed = window.confirm('Are you sure you want to delete this item?');
    if (!confirmed) {
      return new Observable<HttpEvent<any>>();
    }
  }

  return next(request).pipe(
    catchError((err) => {
      return throwError(() => err);
    }),
    map((evt) => {
      return evt;
    })
  );
};
