import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { DynamiConfigService } from './dynami-config.service';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class GServiceService {

  constructor(
    private httpClient: HttpClient,
    private loadConfig: DynamiConfigService) { 
      this.loadConfig.loadConfig().then(() => {
        console.log(this.loadConfig.getConfig('baseAPI'));
      });
    }


   get(url: string ): Observable<any> {
    return this.httpClient.get<any>(this.loadConfig.getConfig('baseAPI') + url,);
  }
}
